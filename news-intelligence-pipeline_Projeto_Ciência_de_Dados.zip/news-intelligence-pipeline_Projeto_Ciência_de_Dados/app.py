
import json
from pathlib import Path

import pandas as pd
import requests
import streamlit as st

from src.coleta import coletar_noticias
from src.armazenamento import salvar_noticias

from src.processamento import (
    noticias_para_dataframe,
    processar_textos,
    gerar_ranking,
    gerar_tfidf,
    processar_noticias,
    salvar_processados,
)

from src.sentimento import (
    analisar_noticias,
    resumir_sentimentos,
)

from src.analise import calcular_metricas


# =========================================================
# CONFIGURAÇÃO
# =========================================================

st.set_page_config(
    page_title="News Intelligence",
    page_icon="📰",
    layout="wide",
    initial_sidebar_state="collapsed",
)

st.title("📰 News Intelligence")

st.caption(
    "Plataforma de inteligência de notícias com coleta de dados, "
    "processamento, NLP, análise de sentimentos e TF-IDF."
)

st.divider()


# =========================================================
# ESTADO DA SESSÃO
# =========================================================

if "resultado_analise" not in st.session_state:
    st.session_state["resultado_analise"] = None

if "arquivos_salvos" not in st.session_state:
    st.session_state["arquivos_salvos"] = None


# =========================================================
# FUNÇÕES AUXILIARES
# =========================================================

def validar_url(url):
    """Verifica se o endereço informado possui uma URL HTTP válida."""

    if not isinstance(url, str) or not url.strip():
        return False

    try:
        from urllib.parse import urlparse

        partes = urlparse(url.strip())

        return (
            partes.scheme in {"http", "https"}
            and bool(partes.hostname)
        )

    except ValueError:
        return False


def carregar_noticias_processadas(caminho):
    """Lê as notícias de um arquivo JSON processado."""

    with Path(caminho).open("r", encoding="utf-8") as arquivo:
        dados = json.load(arquivo)

    noticias = dados.get("noticias", [])

    if not isinstance(noticias, list):
        raise ValueError(
            "O arquivo processado não contém uma lista válida."
        )

    return noticias


def executar_pipeline(url1, url2):
    """
    Coleta os dois portais e executa todas as análises.

    Os resultados são retornados para reutilização na sessão,
    evitando executar novamente o modelo ao salvar os arquivos.
    """

    # =====================================================
    # COLETA
    # =====================================================

    lista1 = coletar_noticias(url1)
    lista2 = coletar_noticias(url2)

    if not lista1:
        raise ValueError(
            f"Nenhuma notícia foi encontrada no primeiro portal: {url1}"
        )

    if not lista2:
        raise ValueError(
            f"Nenhuma notícia foi encontrada no segundo portal: {url2}"
        )

    # =====================================================
    # PROCESSAMENTO E NORMALIZAÇÃO EM MEMÓRIA
    # =====================================================

    lista1, estatisticas_processamento1 = processar_noticias(
        lista1
    )

    lista2, estatisticas_processamento2 = processar_noticias(
        lista2
    )

    # =====================================================
    # DATAFRAMES
    # =====================================================

    df_noticias1 = noticias_para_dataframe(lista1)
    df_noticias2 = noticias_para_dataframe(lista2)

    # =====================================================
    # FREQUÊNCIA DE PALAVRAS
    # =====================================================

    contagem1 = processar_textos(lista1)
    contagem2 = processar_textos(lista2)

    df1 = gerar_ranking(contagem1)
    df2 = gerar_ranking(contagem2)

    # =====================================================
    # TF-IDF
    # =====================================================

    tfidf1 = gerar_tfidf(lista1)
    tfidf2 = gerar_tfidf(lista2)

    # =====================================================
    # SENTIMENTO INDIVIDUAL
    # O modelo é executado uma única vez por manchete.
    # =====================================================

    sentimentos1 = analisar_noticias(lista1)
    sentimentos2 = analisar_noticias(lista2)

    # =====================================================
    # SENTIMENTO GERAL
    # Reutiliza os resultados individuais já calculados.
    # =====================================================

    sentimento1, confianca1 = resumir_sentimentos(
        sentimentos1
    )

    sentimento2, confianca2 = resumir_sentimentos(
        sentimentos2
    )

    # =====================================================
    # MÉTRICAS
    # =====================================================

    metricas1 = calcular_metricas(lista1, contagem1)
    metricas2 = calcular_metricas(lista2, contagem2)

    return {
        "url1": url1,
        "url2": url2,
        "lista1": lista1,
        "lista2": lista2,
        "df_noticias1": df_noticias1,
        "df_noticias2": df_noticias2,
        "contagem1": contagem1,
        "contagem2": contagem2,
        "df1": df1,
        "df2": df2,
        "tfidf1": tfidf1,
        "tfidf2": tfidf2,
        "sentimentos1": sentimentos1,
        "sentimentos2": sentimentos2,
        "sentimento1": sentimento1,
        "sentimento2": sentimento2,
        "confianca1": confianca1,
        "confianca2": confianca2,
        "metricas1": metricas1,
        "metricas2": metricas2,
        "estatisticas_processamento1": estatisticas_processamento1,
        "estatisticas_processamento2": estatisticas_processamento2,
    }


def salvar_resultados(resultado):
    """
    Salva separadamente os dados brutos e processados
    dos dois portais.
    """

    arquivos = {}

    portais = [
        ("Portal 01", resultado["url1"], resultado["lista1"]),
        ("Portal 02", resultado["url2"], resultado["lista2"]),
    ]

    for nome_portal, url, noticias in portais:

        # Salva os dados coletados em data/raw.
        arquivo_raw = salvar_noticias(noticias)

        # Processa a mesma coleta e salva em data/processed.
        noticias_processadas, estatisticas = processar_noticias(
            noticias
        )

        arquivo_processado = salvar_processados(
            noticias_processadas,
            estatisticas,
            metadados_origem=arquivo_raw,
        )

        arquivos[nome_portal] = {
            "url": url,
            "arquivo_raw": str(arquivo_raw.resolve()),
            "arquivo_processado": str(
                arquivo_processado.resolve()
            ),
            "estatisticas": estatisticas,
        }

    return arquivos


# =========================================================
# CONFIGURAÇÃO DOS PORTAIS
# =========================================================

st.header("🌐 Portais para análise")

st.write(
    "Informe dois portais de notícias e clique em analisar. "
    "Ao final, você poderá salvar os dados coletados."
)

col_input1, col_input2 = st.columns(2)

with col_input1:
    with st.container(border=True):
        st.markdown("**PORTAL 01**")

        url1 = st.text_input(
            "URL do primeiro portal",
            placeholder="https://g1.globo.com",
            key="url_portal_1",
        )

with col_input2:
    with st.container(border=True):
        st.markdown("**PORTAL 02**")

        url2 = st.text_input(
            "URL do segundo portal",
            placeholder="https://www.cnnbrasil.com.br",
            key="url_portal_2",
        )


# =========================================================
# BOTÃO PRINCIPAL: ANALISAR
# =========================================================

executar_analise = st.button(
    "🚀 Analisar portais",
    type="primary",
    use_container_width=True,
)

if executar_analise:

    endereco1 = url1.strip().rstrip("/")
    endereco2 = url2.strip().rstrip("/")

    if not validar_url(endereco1) or not validar_url(endereco2):
        st.warning(
            "Informe duas URLs válidas, começando com "
            "http:// ou https://."
        )

    elif endereco1.casefold() == endereco2.casefold():
        st.warning(
            "Informe dois endereços diferentes para comparar os portais."
        )

    else:
        try:
            with st.spinner(
                "🔎 Coletando notícias e executando todas as análises..."
            ):
                novo_resultado = executar_pipeline(
                    endereco1,
                    endereco2,
                )

            st.session_state["resultado_analise"] = novo_resultado

            # Uma nova análise exige uma nova gravação.
            st.session_state["arquivos_salvos"] = None

            st.success(
                "Análise concluída! Confira todos os resultados abaixo."
            )

        except requests.exceptions.HTTPError as erro:
            st.error(f"Erro HTTP durante a coleta: {erro}")

        except requests.exceptions.ConnectionError:
            st.error(
                "Não foi possível estabelecer conexão com um dos portais."
            )

        except requests.exceptions.Timeout:
            st.error(
                "A conexão demorou demais. Tente novamente."
            )

        except Exception as erro:
            st.error(
                f"Erro durante a análise: {erro}"
            )


# =========================================================
# EXIBIÇÃO DOS RESULTADOS
# =========================================================

resultado = st.session_state.get("resultado_analise")

if resultado:

    lista1 = resultado["lista1"]
    lista2 = resultado["lista2"]

    metricas1 = resultado["metricas1"]
    metricas2 = resultado["metricas2"]

    sentimentos1 = resultado["sentimentos1"]
    sentimentos2 = resultado["sentimentos2"]

    df1 = resultado["df1"]
    df2 = resultado["df2"]

    tfidf1 = resultado["tfidf1"]
    tfidf2 = resultado["tfidf2"]

    # =====================================================
    # VISÃO GERAL
    # =====================================================

    st.divider()
    st.header("📊 Visão geral")

    st.caption(
        "Indicadores gerais encontrados nos dados processados."
    )

    kpi1, kpi2, kpi3, kpi4 = st.columns(4)

    with kpi1:
        st.metric(
            "Notícias — Portal 01",
            metricas1["total_noticias"],
        )

    with kpi2:
        st.metric(
            "Notícias — Portal 02",
            metricas2["total_noticias"],
        )

    with kpi3:
        st.metric(
            "Palavras únicas — Portal 01",
            metricas1["palavras_unicas"],
        )

    with kpi4:
        st.metric(
            "Palavras únicas — Portal 02",
            metricas2["palavras_unicas"],
        )

    # =====================================================
    # EXTENSÃO DAS MANCHETES
    # =====================================================

    st.subheader("📏 Extensão das manchetes")

    media1, media2 = st.columns(2)

    with media1:
        st.metric(
            "Média de palavras — Portal 01",
            metricas1["media_palavras_por_noticia"],
        )

    with media2:
        st.metric(
            "Média de palavras — Portal 02",
            metricas2["media_palavras_por_noticia"],
        )

    # =====================================================
    # INTELIGÊNCIA DE LINGUAGEM
    # =====================================================

    st.divider()
    st.header("🧠 Inteligência de linguagem")

    st.caption(
        "Classificação predominante e confiança média atribuída "
        "pelo modelo às manchetes analisadas."
    )

    sentimento_col1, sentimento_col2 = st.columns(2)

    with sentimento_col1:
        with st.container(border=True):
            st.subheader("🌐 Portal 01")

            st.metric(
                "Sentimento predominante",
                resultado["sentimento1"],
            )

            st.caption(
                "Confiança média do modelo: "
                f"{resultado['confianca1']:.2%}"
            )

    with sentimento_col2:
        with st.container(border=True):
            st.subheader("🌐 Portal 02")

            st.metric(
                "Sentimento predominante",
                resultado["sentimento2"],
            )

            st.caption(
                "Confiança média do modelo: "
                f"{resultado['confianca2']:.2%}"
            )

    # =====================================================
    # SENTIMENTO POR MANCHETE
    # =====================================================

    st.subheader("🔎 Sentimento por manchete")

    nlp1, nlp2 = st.columns(2)

    for coluna, sentimentos, nome in [
        (nlp1, sentimentos1, "Portal 01"),
        (nlp2, sentimentos2, "Portal 02"),
    ]:
        with coluna:
            st.markdown(f"#### 🌐 {nome}")

            df_sentimento = pd.DataFrame(sentimentos)

            if not df_sentimento.empty:
                df_sentimento["confianca"] = (
                    df_sentimento["confianca"] * 100
                ).round(2)

                df_sentimento = df_sentimento[
                    ["titulo", "sentimento", "confianca"]
                ].rename(
                    columns={
                        "titulo": "Manchete",
                        "sentimento": "Sentimento",
                        "confianca": "Confiança (%)",
                    }
                )

                st.dataframe(
                    df_sentimento,
                    hide_index=True,
                    use_container_width=True,
                )
            else:
                st.info("Nenhuma manchete disponível.")

    # =====================================================
    # TF-IDF
    # =====================================================

    st.divider()
    st.header("🧠 TF-IDF")

    st.caption(
        "Termos com maior relevância estatística nos conjuntos "
        "de manchetes de cada portal."
    )

    tfidf_col1, tfidf_col2 = st.columns(2)

    for coluna, tfidf, nome in [
        (tfidf_col1, tfidf1, "Portal 01"),
        (tfidf_col2, tfidf2, "Portal 02"),
    ]:
        with coluna:
            st.markdown(f"#### 🌐 {nome}")

            if not tfidf.empty:
                st.dataframe(
                    tfidf,
                    hide_index=True,
                    use_container_width=True,
                )

                st.bar_chart(
                    tfidf.set_index("Palavra")
                )
            else:
                st.info(
                    "Não foi possível calcular o TF-IDF "
                    "com as manchetes disponíveis."
                )

    # =====================================================
    # FREQUÊNCIA DE PALAVRAS
    # =====================================================

    st.divider()
    st.header("📊 Frequência de palavras")

    st.caption(
        "Palavras mais frequentes nas manchetes coletadas."
    )

    freq1, freq2 = st.columns(2)

    for coluna, ranking, nome in [
        (freq1, df1, "Portal 01"),
        (freq2, df2, "Portal 02"),
    ]:
        with coluna:
            st.markdown(f"#### 🌐 {nome}")

            if not ranking.empty:
                st.dataframe(
                    ranking,
                    hide_index=True,
                    use_container_width=True,
                )

                st.bar_chart(
                    ranking.set_index("Palavra")
                )
            else:
                st.info(
                    "Não há palavras suficientes para o ranking."
                )

    # =====================================================
    # MANCHETES COLETADAS
    # =====================================================

    st.divider()
    st.header("📰 Manchetes coletadas")

    st.caption(
        "Acesse as notícias diretamente nos portais de origem."
    )

    manchete1, manchete2 = st.columns(2)

    for coluna, noticias, nome in [
        (manchete1, lista1, "Portal 01"),
        (manchete2, lista2, "Portal 02"),
    ]:
        with coluna:
            st.subheader(f"🌐 {nome}")

            for noticia in noticias[:15]:
                titulo = noticia.get("titulo", "")
                url = noticia.get("url")
                site = noticia.get("site", "")

                with st.container(border=True):
                    st.write(f"**{titulo or 'Manchete sem título'}**")

                    if site:
                        st.caption(site)

                    if url:
                        st.link_button(
                            "🔗 Ler notícia",
                            url,
                            use_container_width=True,
                        )

    # =====================================================
    # DADOS ESTRUTURADOS
    # =====================================================

    with st.expander("🗃️ Ver dados estruturados"):

        dados1, dados2 = st.columns(2)

        with dados1:
            st.markdown("#### Portal 01")

            st.dataframe(
                resultado["df_noticias1"],
                hide_index=True,
                use_container_width=True,
            )

        with dados2:
            st.markdown("#### Portal 02")

            st.dataframe(
                resultado["df_noticias2"],
                hide_index=True,
                use_container_width=True,
            )

    # =====================================================
    # ESTATÍSTICAS DO PROCESSAMENTO
    # =====================================================

    with st.expander("🧹 Qualidade do processamento"):

        qualidade1, qualidade2 = st.columns(2)

        for coluna, estatisticas, nome in [
            (
                qualidade1,
                resultado["estatisticas_processamento1"],
                "Portal 01",
            ),
            (
                qualidade2,
                resultado["estatisticas_processamento2"],
                "Portal 02",
            ),
        ]:
            with coluna:
                st.markdown(f"#### {nome}")

                st.write(
                    f"Notícias originais: "
                    f"{estatisticas['total_original']}"
                )

                st.write(
                    f"Notícias processadas: "
                    f"{estatisticas['total_processado']}"
                )

                st.write(
                    f"Duplicatas removidas: "
                    f"{estatisticas['duplicatas_removidas']}"
                )

                st.write(
                    f"Notícias sem título: "
                    f"{estatisticas['noticias_sem_titulo']}"
                )

                st.write(
                    f"Notícias sem conteúdo: "
                    f"{estatisticas['noticias_sem_conteudo']}"
                )

    # =====================================================
    # BOTÃO FINAL: SALVAR DADOS
    # =====================================================

    st.divider()
    st.header("💾 Armazenamento dos dados")

    st.write(
        "A análise foi concluída. Se desejar, salve os dados "
        "brutos e processados para manter um histórico desta coleta."
    )

    executar_salvamento = st.button(
        "📥 Salvar dados extraídos",
        use_container_width=True,
        type="primary",
    )

    if executar_salvamento:
        try:
            with st.spinner(
                "💾 Salvando os arquivos brutos e processados..."
            ):
                arquivos = salvar_resultados(resultado)

            st.session_state["arquivos_salvos"] = arquivos

            st.success(
                "Dados salvos com sucesso em data/raw/ "
                "e data/processed/!"
            )

        except Exception as erro:
            st.error(
                f"Não foi possível salvar os dados: {erro}"
            )

    # Mantém os caminhos visíveis após o salvamento.
    arquivos_salvos = st.session_state.get("arquivos_salvos")

    if arquivos_salvos:
        st.subheader("📂 Arquivos gerados")

        for nome_portal, arquivos in arquivos_salvos.items():
            with st.container(border=True):
                st.markdown(f"**{nome_portal}**")

                st.caption("Arquivo bruto — data/raw/")

                st.code(
                    arquivos["arquivo_raw"],
                    language=None,
                )

                st.caption("Arquivo processado — data/processed/")

                st.code(
                    arquivos["arquivo_processado"],
                    language=None,
                )


# =========================================================
# RODAPÉ
# =========================================================

st.divider()

st.caption(
    "News Intelligence · Ciência de Dados · NLP"
)
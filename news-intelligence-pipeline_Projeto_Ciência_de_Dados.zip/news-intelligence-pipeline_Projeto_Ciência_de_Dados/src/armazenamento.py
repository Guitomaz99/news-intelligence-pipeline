import json
from datetime import datetime
from pathlib import Path


def salvar_noticias(noticias, diretorio=None):
    """
    Salva notícias coletadas em um arquivo JSON.

    Args:
        noticias (list): Lista de notícias coletadas.
        diretorio (str | Path | None): Pasta de destino.
            Se não informado, utiliza data/raw na raiz do projeto.

    Returns:
        Path: Caminho do arquivo JSON criado.
    """

    if not isinstance(noticias, list):
        raise TypeError(
            "O parâmetro 'noticias' precisa ser uma lista."
        )

    if not noticias:
        raise ValueError(
            "A lista de notícias está vazia. "
            "Nenhum arquivo foi criado."
        )

    if not all(isinstance(noticia, dict) for noticia in noticias):
        raise TypeError(
            "Cada notícia precisa ser um dicionário."
        )

    # Define a pasta de destino.
    if diretorio is None:
        raiz_projeto = Path(__file__).resolve().parent.parent
        pasta_destino = raiz_projeto / "data" / "raw"
    else:
        pasta_destino = Path(diretorio)

    # Cria a pasta caso ela ainda não exista.
    pasta_destino.mkdir(parents=True, exist_ok=True)

    # Registra a data e a hora local com fuso horário.
    agora = datetime.now().astimezone()

    data_coleta = agora.isoformat(timespec="seconds")

    # Inclui microssegundos para reduzir o risco de colisão
    # entre arquivos criados em execuções próximas.
    nome_arquivo = (
        f"noticias_{agora.strftime('%Y%m%d_%H%M%S_%f')}.json"
    )

    caminho_arquivo = pasta_destino / nome_arquivo

    # Organiza os dados brutos e os metadados da coleta.
    dados = {
        "metadados": {
            "coletado_em": data_coleta,
            "total_noticias": len(noticias),
        },
        "noticias": noticias,
    }

    # Salva o arquivo preservando os caracteres em português.
    with caminho_arquivo.open(
        mode="w",
        encoding="utf-8",
    ) as arquivo:
        json.dump(
            dados,
            arquivo,
            ensure_ascii=False,
            indent=4,
        )

    return caminho_arquivo
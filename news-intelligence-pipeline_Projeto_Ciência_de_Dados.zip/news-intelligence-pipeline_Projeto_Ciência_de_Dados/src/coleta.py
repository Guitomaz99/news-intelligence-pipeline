import json
import re
from urllib.parse import (
    urljoin,
    urlparse,
    urldefrag,
    parse_qsl,
    urlencode,
    urlunparse,
)

import requests
from bs4 import BeautifulSoup


# =========================================================
# CONFIGURAÇÕES
# =========================================================

HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
        "AppleWebKit/537.36 (KHTML, like Gecko) "
        "Chrome/120.0.0.0 Safari/537.36"
    ),
    "Accept-Language": "pt-BR,pt;q=0.9,en-US;q=0.8,en;q=0.7",
    "Accept": (
        "text/html,application/xhtml+xml,"
        "application/xml;q=0.9,*/*;q=0.8"
    ),
}

TIMEOUT = 10
LIMITE_NOTICIAS = 15

PARAMETROS_RASTREAMENTO = {
    "fbclid",
    "gclid",
    "ref",
    "referrer",
    "utm_campaign",
    "utm_content",
    "utm_medium",
    "utm_source",
    "utm_term",
}

CATEGORIAS_URL = {
    "politica": "Política",
    "eleicoes": "Eleições",
    "economia": "Economia",
    "mundo": "Mundo",
    "brasil": "Brasil",
    "educacao": "Educação",
    "saude": "Saúde",
    "tecnologia": "Tecnologia",
    "ciencia": "Ciência",
    "meio-ambiente": "Meio ambiente",
    "esportes": "Esportes",
    "esporte": "Esportes",
    "cultura": "Cultura",
    "pop-arte": "Pop & Arte",
    "carros": "Carros",
    "turismo": "Turismo",
    "agronegocios": "Agronegócios",
    "trabalho-e-carreira": "Trabalho e carreira",
    "concursos-e-emprego": "Concursos e emprego",
    "loterias": "Loterias",
    "tecnologia-e-games": "Tecnologia e games",
    "videos": "Vídeos",
    "sp": "São Paulo",
    "rio-de-janeiro": "Rio de Janeiro",
    "minas-gerais": "Minas Gerais",
    "parana": "Paraná",
    "bahia": "Bahia",
    "pernambuco": "Pernambuco",
    "ceara": "Ceará",
    "distrito-federal": "Distrito Federal",
}

CATEGORIAS_GENERICAS = {
    "g1",
    "globo",
    "notícias",
    "noticias",
    "news",
    "home",
    "início",
    "inicio",
    "portal",
    "site",
    "default",
}

AUTORES_GENERICOS = {
    "g1",
    "globo",
    "redação g1",
    "redacao g1",
    "equipe g1",
    "equipe globo",
}


# =========================================================
# LIMPEZA E VALIDAÇÃO
# =========================================================

def limpar_texto(texto):
    """Remove espaços e normaliza textos extraídos do HTML."""

    if not isinstance(texto, str):
        return ""

    return re.sub(r"\s+", " ", texto).strip()


def texto_e_relevante(texto):
    """Filtra textos que provavelmente não são manchetes."""

    texto = limpar_texto(texto)

    if len(texto) < 30 or len(texto) > 300:
        return False

    letras = sum(caractere.isalpha() for caractere in texto)

    if letras < 20:
        return False

    palavras = texto.lower().split()

    if not palavras:
        return False

    taxa_unicidade = len(set(palavras)) / len(palavras)

    if taxa_unicidade < 0.45:
        return False

    termos_interface = {
        "localizando estado",
        "veja o panorama completo",
        "entrar",
        "login",
        "assine",
        "assinar",
        "menu",
        "publicidade",
        "mais lidas",
        "últimas notícias",
        "compartilhar",
    }

    texto_normalizado = texto.lower()

    if any(
        termo in texto_normalizado
        for termo in termos_interface
    ):
        return False

    return True


def normalizar_url(url, url_base):
    """Converte URLs relativas em absolutas e remove rastreadores."""

    if not url:
        return None

    url = url.strip()

    if url.startswith(("#", "javascript:", "mailto:", "tel:")):
        return None

    url_completa = urljoin(url_base, url)
    url_completa, _ = urldefrag(url_completa)

    partes = urlparse(url_completa)

    if partes.scheme not in {"http", "https"}:
        return None

    parametros = [
        (chave, valor)
        for chave, valor in parse_qsl(
            partes.query,
            keep_blank_values=True,
        )
        if chave.lower() not in PARAMETROS_RASTREAMENTO
        and not chave.lower().startswith("utm_")
    ]

    return urlunparse(
        (
            partes.scheme.lower(),
            partes.netloc.lower(),
            partes.path,
            partes.params,
            urlencode(parametros),
            "",
        )
    )


def dominio_compativel(url, url_base):
    """Evita seguir links para outros domínios."""

    dominio_url = urlparse(url).hostname
    dominio_base = urlparse(url_base).hostname

    if not dominio_url or not dominio_base:
        return False

    dominio_url = dominio_url.lower().removeprefix("www.")
    dominio_base = dominio_base.lower().removeprefix("www.")

    return (
        dominio_url == dominio_base
        or dominio_url.endswith("." + dominio_base)
    )


# =========================================================
# EXTRAÇÃO DE METADADOS
# =========================================================

def obter_meta(soup, nomes):
    """Busca metadados por property, name ou itemprop."""

    for nome in nomes:
        tag = soup.find("meta", attrs={"property": nome})

        if not tag:
            tag = soup.find("meta", attrs={"name": nome})

        if not tag:
            tag = soup.find("meta", attrs={"itemprop": nome})

        if tag and tag.get("content"):
            return limpar_texto(tag["content"])

    return None


def percorrer_jsonld(dados):
    """Percorre objetos e listas de JSON-LD recursivamente."""

    if isinstance(dados, dict):
        yield dados

        for valor in dados.values():
            if isinstance(valor, (dict, list)):
                yield from percorrer_jsonld(valor)

    elif isinstance(dados, list):
        for item in dados:
            yield from percorrer_jsonld(item)


def obter_dados_jsonld(soup):
    """Localiza dados estruturados que descrevem uma notícia."""

    candidatos = []

    for script in soup.find_all(
        "script",
        attrs={"type": "application/ld+json"},
    ):
        conteudo = script.string or script.get_text()

        if not conteudo:
            continue

        try:
            dados = json.loads(conteudo)
        except (json.JSONDecodeError, TypeError):
            continue

        candidatos.extend(percorrer_jsonld(dados))

    tipos_artigo = {
        "Article",
        "NewsArticle",
        "ReportageNewsArticle",
        "BlogPosting",
        "AnalysisNewsArticle",
    }

    for item in candidatos:
        tipos = item.get("@type", [])

        if isinstance(tipos, str):
            tipos = [tipos]

        if any(tipo in tipos_artigo for tipo in tipos):
            return item

    return {}


def extrair_nome(valor):
    """Converte autores e categorias em texto simples."""

    if isinstance(valor, str):
        return limpar_texto(valor) or None

    if isinstance(valor, dict):
        nome = valor.get("name")

        if nome:
            return limpar_texto(nome) or None

    if isinstance(valor, list):
        nomes = [
            extrair_nome(item)
            for item in valor
        ]

        nomes = [
            nome
            for nome in nomes
            if nome
        ]

        if nomes:
            return ", ".join(dict.fromkeys(nomes))

    return None


def valor_util(valor, valores_genericos):
    """Descarta valores vazios ou genéricos demais."""

    valor = limpar_texto(valor)

    if not valor:
        return None

    if valor.casefold() in valores_genericos:
        return None

    return valor


# =========================================================
# EXTRAÇÃO DE AUTOR
# =========================================================

def extrair_autor_html(soup):
    """Procura o autor em metadados e elementos HTML."""

    autor_meta = obter_meta(
        soup,
        [
            "author",
            "article:author",
            "parsely-author",
            "twitter:creator",
        ],
    )

    autor_meta = valor_util(
        autor_meta,
        AUTORES_GENERICOS,
    )

    if autor_meta:
        return autor_meta

    seletores = [
        '[itemprop="author"]',
        '[rel="author"]',
        ".content-publication-data__from",
        ".content-publication-data__author",
        ".article-author",
        ".author-name",
        ".author",
        ".byline",
    ]

    for seletor in seletores:
        for elemento in soup.select(seletor):
            # Quando existe um elemento com itemprop=name,
            # preferimos o nome específico do autor.
            nome_elemento = elemento.select_one('[itemprop="name"]')

            if nome_elemento:
                texto = nome_elemento.get_text(" ", strip=True)
            else:
                texto = elemento.get_text(" ", strip=True)

            texto = limpar_texto(texto)

            # Remove prefixos comuns de identificação do autor.
            texto = re.sub(
                r"^(por|by|autor(?:a)?):?\s+",
                "",
                texto,
                flags=re.IGNORECASE,
            ).strip()

            texto = valor_util(texto, AUTORES_GENERICOS)

            if texto and len(texto) <= 150:
                return texto

    return None


# =========================================================
# EXTRAÇÃO DE CATEGORIA
# =========================================================

def extrair_categoria_breadcrumb(soup):
    """Tenta identificar a categoria pelas trilhas de navegação."""

    seletores = [
        'nav[aria-label*="breadcrumb" i] a',
        'nav[aria-label*="navegação" i] a',
        ".breadcrumb a",
        ".breadcrumbs a",
        "ol.breadcrumb a",
    ]

    for seletor in seletores:
        elementos = soup.select(seletor)

        for elemento in reversed(elementos):
            texto = limpar_texto(
                elemento.get_text(" ", strip=True)
            )

            if not texto:
                continue

            if texto.casefold() in CATEGORIAS_GENERICAS:
                continue

            if len(texto) > 60:
                continue

            return texto

    return None


def extrair_categoria_url(url):
    """Infere uma categoria conhecida a partir do caminho da URL."""

    caminho = urlparse(url).path.lower()
    segmentos = [
        segmento
        for segmento in caminho.split("/")
        if segmento
    ]

    # Percorremos os segmentos na ordem da URL para priorizar
    # a seção mais ampla, como politica ou economia.
    for segmento in segmentos:
        if segmento in CATEGORIAS_URL:
            return CATEGORIAS_URL[segmento]

    return None


def extrair_categoria(soup, dados_jsonld, url):
    """Combina metadados, breadcrumbs e URL como alternativas."""

    categoria_jsonld = valor_util(
        extrair_nome(
            dados_jsonld.get("articleSection")
        ),
        CATEGORIAS_GENERICAS,
    )

    if categoria_jsonld:
        return categoria_jsonld

    categoria_meta = valor_util(
        obter_meta(
            soup,
            [
                "article:section",
                "section",
            ],
        ),
        CATEGORIAS_GENERICAS,
    )

    if categoria_meta:
        return categoria_meta

    categoria_breadcrumb = extrair_categoria_breadcrumb(soup)

    if categoria_breadcrumb:
        return categoria_breadcrumb

    return extrair_categoria_url(url)


# =========================================================
# EXTRAÇÃO DO CONTEÚDO
# =========================================================

def extrair_conteudo(soup, dados_jsonld):
    """Tenta obter o corpo principal da notícia."""

    corpo = dados_jsonld.get("articleBody")

    if isinstance(corpo, str) and limpar_texto(corpo):
        return limpar_texto(corpo)

    seletores = [
        '[itemprop="articleBody"]',
        "article",
        ".article-body",
        ".post-content",
        ".story-body",
        ".content-text",
    ]

    for seletor in seletores:
        elemento = soup.select_one(seletor)

        if not elemento:
            continue

        # Remove elementos que normalmente não fazem
        # parte do conteúdo editorial.
        for indesejado in elemento.select(
            "script, style, nav, footer, aside, "
            "form, button, figure, "
            ".advertisement, .social-share, .related-content"
        ):
            indesejado.decompose()

        paragrafos = [
            limpar_texto(
                paragrafo.get_text(" ", strip=True)
            )
            for paragrafo in elemento.find_all("p")
        ]

        paragrafos = [
            paragrafo
            for paragrafo in paragrafos
            if len(paragrafo) >= 40
        ]

        if paragrafos:
            return "\n\n".join(
                dict.fromkeys(paragrafos)
            )

    return None


# =========================================================
# EXTRAÇÃO DE UMA NOTÍCIA
# =========================================================

def extrair_detalhes_noticia(session, url, site):
    """
    Visita uma página individual e extrai os dados disponíveis.

    Se a página não puder ser acessada, retorna os dados básicos
    para não interromper a coleta do portal.
    """

    noticia = {
        "titulo": None,
        "url": url,
        "site": site,
        "data_publicacao": None,
        "autor": None,
        "categoria": None,
        "resumo": None,
        "conteudo": None,
    }

    try:
        resposta = session.get(
            url,
            headers=HEADERS,
            timeout=TIMEOUT,
        )

        resposta.raise_for_status()

        soup = BeautifulSoup(
            resposta.text,
            "html.parser",
        )

        dados_jsonld = obter_dados_jsonld(soup)

        # TÍTULO
        titulo_jsonld = dados_jsonld.get("headline")

        titulo_meta = obter_meta(
            soup,
            [
                "og:title",
                "twitter:title",
            ],
        )

        titulo_html = soup.find("h1")

        titulo_h1 = (
            limpar_texto(
                titulo_html.get_text(" ", strip=True)
            )
            if titulo_html
            else None
        )

        noticia["titulo"] = (
            limpar_texto(titulo_jsonld)
            or titulo_meta
            or titulo_h1
        )

        # DATA DE PUBLICAÇÃO
        noticia["data_publicacao"] = (
            dados_jsonld.get("datePublished")
            or dados_jsonld.get("dateCreated")
            or obter_meta(
                soup,
                [
                    "article:published_time",
                    "datePublished",
                    "date",
                    "pubdate",
                ],
            )
        )

        # AUTOR
        autor_jsonld = extrair_nome(
            dados_jsonld.get("author")
            or dados_jsonld.get("creator")
        )

        noticia["autor"] = (
            valor_util(
                autor_jsonld,
                AUTORES_GENERICOS,
            )
            or extrair_autor_html(soup)
        )

        # CATEGORIA
        noticia["categoria"] = extrair_categoria(
            soup,
            dados_jsonld,
            url,
        )

        # RESUMO / DESCRIÇÃO
        noticia["resumo"] = (
            limpar_texto(
                dados_jsonld.get("description")
            )
            or obter_meta(
                soup,
                [
                    "og:description",
                    "description",
                    "twitter:description",
                ],
            )
        )

        # CONTEÚDO
        noticia["conteudo"] = extrair_conteudo(
            soup,
            dados_jsonld,
        )

    except requests.RequestException:
        # A página individual pode bloquear ou falhar.
        # Mantemos a notícia com os dados básicos.
        pass

    except (ValueError, TypeError, AttributeError):
        # Evita que metadados inesperados interrompam a coleta.
        pass

    return noticia


# =========================================================
# COLETA DE NOTÍCIAS DO PORTAL
# =========================================================

def coletar_noticias(url, limite=LIMITE_NOTICIAS):
    """
    Coleta manchetes da página inicial e tenta enriquecer
    cada registro com metadados da página individual.
    """

    url = url.strip()

    if not url.startswith(("http://", "https://")):
        raise ValueError(
            "Informe uma URL completa, começando com http:// ou https://."
        )

    session = requests.Session()

    try:
        resposta = session.get(
            url,
            headers=HEADERS,
            timeout=TIMEOUT,
        )

        resposta.raise_for_status()

        soup = BeautifulSoup(
            resposta.text,
            "html.parser",
        )

        site = urlparse(url).hostname or url
        site = site.removeprefix("www.")

        candidatos = []
        urls_vistas = set()
        titulos_vistos = set()

        # Descobre possíveis notícias na página inicial.
        for tag in soup.find_all("a", href=True):
            titulo = limpar_texto(
                tag.get_text(" ", strip=True)
            )

            if not texto_e_relevante(titulo):
                continue

            url_noticia = normalizar_url(
                tag["href"],
                url,
            )

            if not url_noticia:
                continue

            if not dominio_compativel(url_noticia, url):
                continue

            partes_url = urlparse(url_noticia)

            if partes_url.path in {"", "/"}:
                continue

            chave_titulo = titulo.casefold()

            if url_noticia in urls_vistas:
                continue

            if chave_titulo in titulos_vistos:
                continue

            urls_vistas.add(url_noticia)
            titulos_vistos.add(chave_titulo)

            candidatos.append({
                "titulo": titulo,
                "url": url_noticia,
                "site": site,
            })

            if len(candidatos) >= limite:
                break

        # Visita cada notícia para buscar informações adicionais.
        noticias = []

        for candidato in candidatos:
            noticia = extrair_detalhes_noticia(
                session,
                candidato["url"],
                site,
            )

            # Se a página individual não fornecer título,
            # utiliza a manchete encontrada na página inicial.
            if not noticia.get("titulo"):
                noticia["titulo"] = candidato["titulo"]

            noticia["url"] = candidato["url"]
            noticia["site"] = site

            noticias.append(noticia)

        return noticias

    finally:
        session.close()
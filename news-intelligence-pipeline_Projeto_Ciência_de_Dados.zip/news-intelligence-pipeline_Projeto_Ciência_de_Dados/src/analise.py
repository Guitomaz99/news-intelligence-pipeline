def calcular_metricas(lista, contagem):
    """
    Calcula métricas gerais das notícias coletadas.

    Retorna:
    - total de notícias
    - quantidade de palavras únicas
    - quantidade de sites
    - média de palavras por notícia
    """

    total_noticias = len(lista)

    palavras_unicas = len(contagem)

    sites = set()

    total_palavras = 0

    for noticia in lista:

        # Nova estrutura:
        # {
        #     "titulo": "...",
        #     "url": "...",
        #     "site": "..."
        # }

        if isinstance(noticia, dict):

            site = noticia.get(
                "site"
            )

            if site:
                sites.add(site)

            titulo = noticia.get(
                "titulo",
                ""
            )

            palavras = titulo.split()

            total_palavras += len(
                palavras
            )

        # Compatibilidade com listas antigas
        elif isinstance(noticia, str):

            total_palavras += len(
                noticia.split()
            )

    quantidade_sites = len(sites)

    if total_noticias > 0:

        media_palavras = (
            total_palavras / total_noticias
        )

    else:

        media_palavras = 0

    metricas = {
        "total_noticias": total_noticias,
        "palavras_unicas": palavras_unicas,
        "quantidade_sites": quantidade_sites,
        "media_palavras_por_noticia": round(
            media_palavras,
            2
        )
    }

    return metricas
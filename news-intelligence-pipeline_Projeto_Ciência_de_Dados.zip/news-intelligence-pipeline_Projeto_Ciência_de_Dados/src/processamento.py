
import json
import re
from collections import Counter
from datetime import datetime
from pathlib import Path
from urllib.parse import (
    parse_qsl,
    urlencode,
    urlparse,
    urlunparse,
)

import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer


# =========================================================
# CONFIGURAÇÕES
# =========================================================

RAIZ_PROJETO = Path(__file__).resolve().parent.parent
PASTA_RAW = RAIZ_PROJETO / "data" / "raw"
PASTA_PROCESSED = RAIZ_PROJETO / "data" / "processed"

CAMPOS_TEXTO = (
    "titulo",
    "site",
    "autor",
    "categoria",
    "resumo",
)

PARAMETROS_RASTREAMENTO = {
    "fbclid",
    "gclid",
    "ref",
    "referrer",
    "utm_campaign",
    "utm_content",
    "utm_medium",
    "utm_source",
    "utm_term",
}

STOPWORDS = {
    "a", "à", "agora", "ainda", "além", "algo", "algum",
    "alguma", "algumas", "alguns", "ante", "ao", "aos",
    "apenas", "as", "até", "com", "como", "contra",
    "da", "das", "de", "dela", "delas", "dele", "deles",
    "depois", "do", "dos", "e", "ela", "elas", "ele",
    "eles", "em", "entre", "era", "essa", "essas", "esse",
    "esses", "esta", "está", "estão", "estas", "este",
    "estes", "eu", "foi", "foram", "há", "isso", "isto",
    "já", "lhe", "lhes", "mais", "mas", "me", "mesmo",
    "meu", "minha", "muito", "na", "nas", "nem", "no",
    "nos", "nós", "nossa", "nosso", "num", "numa", "o",
    "os", "ou", "outra", "outras", "outro", "outros",
    "para", "pela", "pelas", "pelo", "pelos", "por",
    "porque", "qual", "quando", "que", "quem", "se",
    "sem", "ser", "seu", "sua", "são", "sob", "sobre",
    "também", "te", "tem", "têm", "ter", "todos", "toda",
    "todas", "todo", "tu", "um", "uma", "umas", "uns",
    "vai", "vem", "você", "vocês",
}


# =========================================================
# FUNÇÕES AUXILIARES DE TEXTO
# =========================================================

def obter_texto_noticia(noticia):
    """Extrai a manchete de uma notícia em formato dict ou str."""

    if isinstance(noticia, dict):
        titulo = noticia.get("titulo", "")
    elif isinstance(noticia, str):
        titulo = noticia
    else:
        return ""

    if not isinstance(titulo, str):
        return ""

    return titulo.strip()


def limpar_texto(texto):
    """
    Remove espaços duplicados e normaliza um texto.

    Valores ausentes ou que não sejam strings são preservados
    como None.
    """

    if not isinstance(texto, str):
        return None

    texto = re.sub(r"\s+", " ", texto).strip()

    return texto or None


def limpar_conteudo(texto):
    """Limpa o conteúdo preservando a separação entre parágrafos."""

    if not isinstance(texto, str):
        return None

    paragrafos = []

    for linha in texto.splitlines():
        linha_limpa = limpar_texto(linha)

        if linha_limpa:
            paragrafos.append(linha_limpa)

    if not paragrafos:
        return None

    return "\n\n".join(paragrafos)


def tokenizar_texto(texto):
    """Converte um texto em palavras normalizadas, sem stopwords."""

    if not isinstance(texto, str):
        return []

    palavras = re.findall(
        r"[a-zA-ZÀ-ÖØ-öø-ÿ]+",
        texto.casefold(),
    )

    return [
        palavra
        for palavra in palavras
        if palavra not in STOPWORDS and len(palavra) > 1
    ]


# =========================================================
# NORMALIZAÇÃO DE URL
# =========================================================

def normalizar_url(url):
    """
    Normaliza uma URL para ajudar a identificar duplicatas.

    Remove parâmetros comuns de rastreamento e fragmentos.
    """

    if not isinstance(url, str) or not url.strip():
        return None

    try:
        partes = urlparse(url.strip())

        if partes.scheme.lower() not in {"http", "https"}:
            return url.strip().casefold()

        host = (partes.hostname or "").lower()

        if not host:
            return url.strip().casefold()

        porta = partes.port

        if porta is not None:
            host = f"{host}:{porta}"

        caminho = partes.path.rstrip("/") or "/"

        parametros = [
            (chave, valor)
            for chave, valor in parse_qsl(
                partes.query,
                keep_blank_values=True,
            )
            if chave.lower() not in PARAMETROS_RASTREAMENTO
            and not chave.lower().startswith("utm_")
        ]

        return urlunparse(
            (
                partes.scheme.lower(),
                host,
                caminho,
                partes.params,
                urlencode(parametros),
                "",
            )
        )

    except (ValueError, TypeError):
        return url.strip().casefold()


# =========================================================
# NORMALIZAÇÃO DE NOTÍCIAS
# =========================================================

def normalizar_noticia(noticia):
    """Padroniza os campos sem inventar informações."""

    noticia_limpa = dict(noticia)

    for campo in CAMPOS_TEXTO:
        noticia_limpa[campo] = limpar_texto(
            noticia_limpa.get(campo)
        )

    noticia_limpa["url"] = limpar_texto(
        noticia_limpa.get("url")
    )

    noticia_limpa["data_publicacao"] = limpar_texto(
        noticia_limpa.get("data_publicacao")
    )

    noticia_limpa["conteudo"] = limpar_conteudo(
        noticia_limpa.get("conteudo")
    )

    campos_obrigatorios = [
        "titulo",
        "url",
        "site",
        "data_publicacao",
        "autor",
        "categoria",
        "resumo",
        "conteudo",
    ]

    for campo in campos_obrigatorios:
        noticia_limpa.setdefault(campo, None)

    return noticia_limpa


# =========================================================
# IDENTIFICAÇÃO E TRATAMENTO DE DUPLICATAS
# =========================================================

def obter_chave_duplicidade(noticia):
    """Prioriza a URL normalizada; na ausência dela, usa o título."""

    url = normalizar_url(noticia.get("url"))

    if url:
        return ("url", url)

    titulo = limpar_texto(noticia.get("titulo"))

    if titulo:
        return ("titulo", titulo.casefold())

    return None


def mesclar_noticias(existente, nova):
    """Combina registros duplicados preservando dados úteis."""

    resultado = dict(existente)

    for campo, valor_novo in nova.items():
        valor_atual = resultado.get(campo)

        if valor_atual is None or valor_atual == "":
            if valor_novo is not None and valor_novo != "":
                resultado[campo] = valor_novo

        elif campo in {"conteudo", "resumo"}:
            if isinstance(valor_novo, str) and isinstance(
                valor_atual, str
            ):
                if len(valor_novo) > len(valor_atual):
                    resultado[campo] = valor_novo

    return resultado


def remover_duplicatas(noticias):
    """Remove duplicatas e combina informações complementares."""

    unicas = []
    indices = {}
    duplicatas = 0

    for noticia in noticias:
        chave = obter_chave_duplicidade(noticia)

        if chave is None:
            unicas.append(noticia)
            continue

        if chave in indices:
            indice = indices[chave]

            unicas[indice] = mesclar_noticias(
                unicas[indice],
                noticia,
            )

            duplicatas += 1

        else:
            indices[chave] = len(unicas)
            unicas.append(noticia)

    return unicas, duplicatas


# =========================================================
# PROCESSAMENTO E ESTATÍSTICAS
# =========================================================

def processar_noticias(noticias):
    """Normaliza as notícias, remove duplicatas e calcula estatísticas."""

    if not isinstance(noticias, list):
        raise TypeError(
            "O parâmetro 'noticias' precisa ser uma lista."
        )

    if not all(isinstance(item, dict) for item in noticias):
        raise TypeError(
            "Cada notícia precisa ser um dicionário."
        )

    total_original = len(noticias)

    noticias_limpa = [
        normalizar_noticia(noticia)
        for noticia in noticias
    ]

    noticias_unicas, duplicatas_removidas = remover_duplicatas(
        noticias_limpa
    )

    estatisticas = {
        "total_original": total_original,
        "total_processado": len(noticias_unicas),
        "duplicatas_removidas": duplicatas_removidas,
        "noticias_sem_titulo": sum(
            not noticia.get("titulo")
            for noticia in noticias_unicas
        ),
        "noticias_sem_conteudo": sum(
            not noticia.get("conteudo")
            for noticia in noticias_unicas
        ),
    }

    return noticias_unicas, estatisticas


# =========================================================
# CONVERSÃO PARA DATAFRAME
# =========================================================

def noticias_para_dataframe(noticias):
    """Converte notícias em uma tabela pandas."""

    colunas = [
        "titulo",
        "url",
        "site",
        "data_publicacao",
        "autor",
        "categoria",
        "resumo",
        "conteudo",
    ]

    registros = []

    for noticia in noticias:
        if isinstance(noticia, dict):
            registros.append(noticia)

        elif isinstance(noticia, str):
            registros.append({"titulo": noticia})

    return pd.DataFrame(
        registros,
        columns=colunas,
    )


# =========================================================
# FREQUÊNCIA DE PALAVRAS
# =========================================================

def processar_textos(lista):
    """
    Conta as palavras das manchetes.

    Retorna um Counter com palavra e frequência.
    """

    contagem = Counter()

    for noticia in lista:
        titulo = obter_texto_noticia(noticia)
        contagem.update(tokenizar_texto(titulo))

    return contagem


def gerar_ranking(contagem, limite=10):
    """
    Gera um ranking de palavras por frequência.

    Retorna um DataFrame com as colunas Palavra e Frequência.
    """

    colunas = ["Palavra", "Frequência"]

    if not contagem:
        return pd.DataFrame(columns=colunas)

    ranking = contagem.most_common(max(0, limite))

    return pd.DataFrame(
        ranking,
        columns=colunas,
    )


# =========================================================
# TF-IDF
# =========================================================

def gerar_tfidf(lista, limite=10):
    """
    Calcula TF-IDF usando cada manchete como um documento.

    Retorna as palavras com maior média de TF-IDF.
    """

    colunas = ["Palavra", "TF-IDF"]

    documentos = [
        obter_texto_noticia(noticia)
        for noticia in lista
    ]

    documentos = [
        documento
        for documento in documentos
        if documento
    ]

    if len(documentos) < 2:
        return pd.DataFrame(columns=colunas)

    try:
        vetorizar = TfidfVectorizer(
            lowercase=True,
            stop_words=list(STOPWORDS),
            token_pattern=r"(?u)\b[a-zA-ZÀ-ÖØ-öø-ÿ]{2,}\b",
            max_features=1000,
        )

        matriz = vetorizar.fit_transform(documentos)
        palavras = vetorizar.get_feature_names_out()

        medias = matriz.mean(axis=0).A1

        ranking = sorted(
            zip(palavras, medias),
            key=lambda item: item[1],
            reverse=True,
        )[:max(0, limite)]

        return pd.DataFrame(
            ranking,
            columns=colunas,
        )

    except ValueError:
        # Pode ocorrer quando todas as palavras são stopwords
        # ou quando não existe vocabulário suficiente.
        return pd.DataFrame(columns=colunas)


# =========================================================
# LEITURA DO JSON BRUTO
# =========================================================

def obter_arquivo_raw(caminho=None):
    """
    Retorna o caminho do JSON bruto.

    Se nenhum caminho for informado, seleciona o arquivo
    mais recente de data/raw.
    """

    if caminho is not None:
        arquivo = Path(caminho)

        if not arquivo.is_absolute():
            arquivo = RAIZ_PROJETO / arquivo

        if not arquivo.is_file():
            raise FileNotFoundError(
                f"Arquivo bruto não encontrado: {arquivo}"
            )

        return arquivo

    arquivos = sorted(
        PASTA_RAW.glob("noticias_*.json"),
        key=lambda arquivo: arquivo.stat().st_mtime,
        reverse=True,
    )

    if not arquivos:
        raise FileNotFoundError(
            "Nenhum arquivo noticias_*.json foi encontrado "
            f"em {PASTA_RAW}. Execute a coleta primeiro."
        )

    return arquivos[0]


def carregar_noticias_raw(caminho=None):
    """Lê um JSON bruto e retorna metadados, notícias e arquivo."""

    arquivo = obter_arquivo_raw(caminho)

    with arquivo.open("r", encoding="utf-8") as entrada:
        dados = json.load(entrada)

    if not isinstance(dados, dict):
        raise ValueError(
            "O JSON precisa conter um objeto com metadados e notícias."
        )

    noticias = dados.get("noticias")

    if not isinstance(noticias, list):
        raise ValueError(
            "O JSON não contém uma lista válida no campo 'noticias'."
        )

    return dados.get("metadados", {}), noticias, arquivo


# =========================================================
# SALVAMENTO DOS DADOS PROCESSADOS
# =========================================================

def salvar_processados(
    noticias,
    estatisticas,
    metadados_origem=None,
    diretorio=None,
):
    """Salva notícias processadas em um novo arquivo JSON."""

    if diretorio is None:
        pasta_destino = PASTA_PROCESSED
    else:
        pasta_destino = Path(diretorio)

    pasta_destino.mkdir(parents=True, exist_ok=True)

    agora = datetime.now().astimezone()

    nome_arquivo = (
        f"noticias_processadas_"
        f"{agora.strftime('%Y%m%d_%H%M%S_%f')}.json"
    )

    caminho_saida = pasta_destino / nome_arquivo

    dados_saida = {
        "metadados": {
            "processado_em": agora.isoformat(timespec="seconds"),
            "total_noticias": len(noticias),
            "arquivo_origem": (
                Path(metadados_origem).name
                if metadados_origem
                else None
            ),
            "estatisticas": estatisticas,
        },
        "noticias": noticias,
    }

    with caminho_saida.open("w", encoding="utf-8") as saida:
        json.dump(
            dados_saida,
            saida,
            ensure_ascii=False,
            indent=4,
        )

    return caminho_saida


# =========================================================
# EXECUÇÃO COMPLETA DO PROCESSAMENTO
# =========================================================

def processar_arquivo(caminho=None, diretorio_saida=None):
    """
    Lê um JSON bruto, processa as notícias e salva o resultado.

    Retorna o caminho do arquivo processado e as estatísticas.
    """

    metadados, noticias, arquivo_origem = carregar_noticias_raw(
        caminho
    )

    noticias_processadas, estatisticas = processar_noticias(
        noticias
    )

    caminho_saida = salvar_processados(
        noticias_processadas,
        estatisticas,
        metadados_origem=arquivo_origem,
        diretorio=diretorio_saida,
    )

    return caminho_saida, estatisticas
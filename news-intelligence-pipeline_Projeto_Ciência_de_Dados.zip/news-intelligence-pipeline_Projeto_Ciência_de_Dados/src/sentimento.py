from transformers import pipeline

# ==========================================
# MODELO DE SENTIMENTO
# ==========================================

modelo_sentimento = pipeline(
    "sentiment-analysis",
    model=(
        "lxyuan/"
        "distilbert-base-multilingual-cased-sentiments-student"
    )
)


# ==========================================
# CONVERSÃO DO SENTIMENTO
# ==========================================

def traduzir_sentimento(label):
    """
    Converte o resultado do modelo para
    uma classificação em português.
    """

    mapa = {
        "positive": "😊 Positivo",
        "negative": "😡 Negativo",
        "neutral": "😐 Neutro",
    }

    return mapa.get(
        label.lower(),
        "😐 Neutro",
    )


# ==========================================
# ANÁLISE DE UMA MANCHETE
# ==========================================

def analisar_manchete(texto):
    """
    Analisa uma única manchete.

    Retorna:
    - sentimento
    - confiança do modelo
    """

    if not isinstance(texto, str) or not texto.strip():
        return "😐 Neutro", 0.0

    resultado = modelo_sentimento(
        texto.strip()
    )[0]

    sentimento = traduzir_sentimento(
        resultado["label"]
    )

    confianca = float(
        resultado["score"]
    )

    return sentimento, confianca


# ==========================================
# ANÁLISE INDIVIDUAL DAS NOTÍCIAS
# ==========================================

def analisar_noticias(lista):
    """
    Analisa individualmente as notícias.

    Aceita dicionários de notícias ou strings.

    Retorna uma lista contendo:
    - titulo
    - url
    - site
    - sentimento
    - confianca
    """

    resultados = []

    for noticia in lista:

        if isinstance(noticia, dict):

            titulo = noticia.get("titulo", "")
            url = noticia.get("url")
            site = noticia.get("site")

        elif isinstance(noticia, str):

            titulo = noticia
            url = None
            site = None

        else:
            continue

        if not isinstance(titulo, str) or not titulo.strip():
            continue

        sentimento, confianca = analisar_manchete(
            titulo
        )

        resultados.append({
            "titulo": titulo.strip(),
            "url": url,
            "site": site,
            "sentimento": sentimento,
            "confianca": round(confianca, 4),
        })

    return resultados


# ==========================================
# RESUMO DOS SENTIMENTOS
# ==========================================

def resumir_sentimentos(resultados):
    """
    Calcula o sentimento predominante e a confiança média
    a partir de resultados já analisados.

    Não executa novamente o modelo de NLP.

    Retorna:
    - sentimento predominante
    - confiança média
    """

    if not resultados:
        return "😐 Neutro", 0.0

    quantidade_sentimentos = {
        "😊 Positivo": 0,
        "😡 Negativo": 0,
        "😐 Neutro": 0,
    }

    confiancas = []

    for resultado in resultados:

        sentimento = resultado.get("sentimento")
        confianca = resultado.get("confianca", 0.0)

        if sentimento in quantidade_sentimentos:
            quantidade_sentimentos[sentimento] += 1

        if isinstance(confianca, (int, float)):
            confiancas.append(float(confianca))

    sentimento_predominante = max(
        quantidade_sentimentos,
        key=quantidade_sentimentos.get,
    )

    confianca_media = (
        sum(confiancas) / len(confiancas)
        if confiancas
        else 0.0
    )

    return (
        sentimento_predominante,
        confianca_media,
    )


# ==========================================
# ANÁLISE GERAL
# ==========================================

def analisar_sentimento(lista):
    """
    Mantém a compatibilidade com o app.py atual.

    Analisa as notícias e retorna:
    - sentimento predominante
    - confiança média
    """

    resultados = analisar_noticias(lista)

    return resumir_sentimentos(
        resultados
    )